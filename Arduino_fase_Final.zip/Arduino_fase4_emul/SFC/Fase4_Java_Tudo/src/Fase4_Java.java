/*
 *   MIETI 2021/2022 EMULAÇÃO E SIMULAÇÃO DE REDES DE TELECOMUNICAÇÕES
 *   GRUPO 4 - FASE 1.2
 *   CATARINA AMORIM A93094
 *   JOÃO MOURA A93099
 *   LUÍS PINTO A94155
 *   MIGUEL PEREIRA A94152
 * *  */

import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import com.fazecast.jSerialComm.SerialPort;

import javax.print.DocFlavor;
import javax.swing.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.lang.*;

public class Fase4_Java extends JFrame {


    /*public Tester() {
        JFrame frame = new JFrame();
        JPanel Jpanel_chat = new JPanel();
        Jpanel_chat.setBorder(BorderFactory.createEmptyBorder());
        Jpanel_chat.setLayout(new GridLayout(0,1));

        frame.add(Jpanel_chat, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("CHAT");
        frame.pack();
        frame.setVisible(true);
    }*/

    public static void main(String[] args) throws IOException {
       /* SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new chatbox();
            }
        });*/
        int option; //para opções
        long start_clock; //para medições de tempo
        long turnoff_clock;
        Scanner input = new Scanner(System.in);
        long total_time;
        String OS_BEING_USED = System.getProperty("os.name");
        SerialPort[] AvailablePorts;
        boolean Sair = false;

        int counter = 0;
        //ver disponibilidade das portas (getCommPorts / check ports/
        AvailablePorts = SerialPort.getCommPorts();
        if (AvailablePorts.length == 0) {
            System.out.println("No Ports Available");
            System.out.println("Press Any key to Exit.");
            String exit_option = input.nextLine();
            System.exit(1);
        }

        //Selecionar Port
        for (SerialPort ToChoose_Port : AvailablePorts) {
            counter++;
            System.out.println(counter - 1 + " - " + ToChoose_Port.getSystemPortName());
        }
        int Sent_Port = input.nextInt();
        int Choosen_port = VerifyPort(Sent_Port, AvailablePorts);
        SerialPort Selected_Port = AvailablePorts[Choosen_port]; //É necessário verificar se o port está aberto

        //configuração da porta série (baudrate, bits (8), stop bits (1), paridade (0))
        Selected_Port.setComPortParameters(115200, 8, 1, 0);
        try {
            Thread.sleep(2000); //Como ao selecionarmos a porta o arduino é resetado, temos de esperar que ele renicie, logo são dados 2 segundos para o mesmo ser feito
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        do {
            Selected_Port.openPort();
            String File_Store;
            //while(true){
            if (OS_BEING_USED.contains("win")) {
                System.out.print("\033[H\033[2J"); //limpar consola
                System.out.flush();
                System.out.println("SYSTEM BEING USED: " + OS_BEING_USED);
            }
            if (OS_BEING_USED.contains("nix") || OS_BEING_USED.contains("nux") || OS_BEING_USED.contains("aix")) {
                System.out.print("\033[H\033[2J"); //limpar consola
                System.out.flush();
                System.out.println("SYSTEM BEING USED: " + OS_BEING_USED);
            }

            System.out.println("SELECTED PORT: " + Selected_Port);
            System.out.println(" _________________________________");
            System.out.println("<1.ENVIAR TEXTO                     >");
            System.out.println("<2.ENVIAR IMAGEM                    >");
            System.out.println("<3.RECEBER TEXTO                    >");
            System.out.println("<4.RECEBER IMAGEM                   >");
            System.out.println("<5.VERIFICAR CONEXÃO                >");
            System.out.println("<6.CHAT                             >");
            System.out.println("<7.SAIR                             >");
            System.out.println(" ---------------------------------");

            option = input.nextInt();

            while (option < 1 || option > 7) {
                System.out.println("Choose an valid option");
                option = input.nextInt();
            }

            switch (option) {
                case 1: //Enviar mensagem tentar fazer texto escrito em consola, mas também texto de um ficheiro
                    start_clock = System.currentTimeMillis();
                    SendText_File(Selected_Port);
                    turnoff_clock = System.currentTimeMillis();
                    total_time = -(start_clock - turnoff_clock);
                    System.out.println("This message took " + total_time + "ms to be sent");
                    Selected_Port.closePort();
                    break;
                case 2: //Enviar imagem (introduzir path)
                    start_clock = System.currentTimeMillis();
                    SendImage(Selected_Port);
                    turnoff_clock = System.currentTimeMillis();
                    total_time = -(start_clock - turnoff_clock);
                    System.out.println("This image took " + total_time + "ms to be sent");
                    Selected_Port.closePort();
                    break;
                case 3: //Receber Mensagem de texto
                    System.out.println("Introduza o path exato onde quer que o ficheiro de texto seja guardado");
                    File_Store = input.next();
                    //File_Store = "/Files_Java/Receber/Hinorecived.txt";
                    Receive_Text(Selected_Port, File_Store);
                    System.out.println("I arrived");
                    Selected_Port.closePort();
                    break;
                case 4: //Receber Imagem
                    System.out.println("Introduza o path exato onde quer que a imagem seja guardado");
                    File_Store = input.next();
                    Receive_Image(Selected_Port, File_Store);
                    System.out.println("I arrived");
                    Selected_Port.closePort();
                    break;
                case 5: //Verificar Conexão verifica se o port ainda está ligado, e envia uma mensagem de teste entre o arduinos.

                    break;
                case 6:
                    chat(Selected_Port);
                    Selected_Port.closePort();
                    break;
                case 7: //Sair do programa
                    Selected_Port.closePort();
                    Sair = true;
                    System.out.println("The Program will exit now.");
                    System.exit(0);
                    break;
            }
        } while (!Sair);
    }

    // Verifica se o Port selecionado está aberto e caso não esteja o utilizador pode sair do programa ou então escolher outro port.
    public static int VerifyPort(int NeedVerification_Port, SerialPort[] ArrayofPorts){
        int tobereturned = 0;
        boolean Port_Verified = false;
        Scanner input = new Scanner(System.in);
        while (!Port_Verified) {
            SerialPort Verication_Port = ArrayofPorts[NeedVerification_Port];
            Verication_Port.openPort();
            if (Verication_Port.openPort()) {
                Port_Verified = true;
                tobereturned = NeedVerification_Port;
                return tobereturned;
            } else {
                System.out.println("It seems that this port is closed. \n Choose another one.");
                NeedVerification_Port = input.nextInt();
            }
        }
        return tobereturned;
    }

    //Função para enviar texto contido em ficheiro entre os DevKits
    public static void SendText_File(SerialPort Selected_Port) throws IOException{
        //String OS_BEING_USED = OS_USED();
        int nPackets; //A quantidade de pacotes a enviar após a divisão da mensagem em tramas de 30 bits
        float BytesFromFile;
        boolean sucesso = false;
        int String_size; //Cantidade de bytes contida no ficheiro de texto
        int text_newpos = 0; //A cada iteração a posição do array que contem o texto tem de ser incrementada
        int counter = 0;
        boolean retorno = true;
        int insert_counter = 0; // counter para a inserção dos dados do ficheiro na payload a enviar
        Scanner input2 = new Scanner(System.in);

            boolean sucesso_envio = false;
            int size_contador = 0;
            System.out.println("Introduza o path exato do ficheiro de texto a enviar");
            String Path = new String();
            try {
                Path = input2.nextLine();
            }catch(InvalidPathException ex){
                System.out.println("Path Invalido escreva \n Escreva um Path Valido");
            }
            //String Text_File2 = (Files.readString(Paths.get("/home/johnnyminho/IdeaProjects/Files_Java/Boas")));
            byte[] Text_File = (Files.readAllBytes(Paths.get(Path)));
            //OutputStream output = Selected_Port.getOutputStream();
            String_size = Text_File.length;
            BytesFromFile = Text_File.length;
            nPackets = (int) Math.ceil(BytesFromFile / 30);
            System.out.println(" " + nPackets);
            for (counter = 0; counter < nPackets; counter++) {
                sucesso_envio = false;
                byte[] bytesToSend = new byte[30];
                if (String_size > 30) {
                    size_contador = 30;
                } else {
                    size_contador = String_size;
                    bytesToSend = new byte[size_contador];
                }
                for (insert_counter = 0; insert_counter < size_contador; insert_counter++) {
                    bytesToSend[insert_counter] = Text_File[insert_counter + text_newpos];
                    System.out.print(" " + (char) bytesToSend[insert_counter]);
                }
                Selected_Port.writeBytes(bytesToSend, size_contador);
                while(Selected_Port.bytesAwaitingWrite() <=0 && counter == 1){
                    if(counter == 1){
                        break; // este passo é necessário visto que o número de bytes à espera de serem escritos antes do 1 packet é sempre 0
                    }
                }
              /*  try {
                    Thread.sleep(1);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }*/
                text_newpos = text_newpos + 30; //proxima posição no ficheiro de texto será 30 bytes à frente da que foi enviad
                while (!sucesso_envio) {
                    byte[] bufferackfinal = new byte[2];
                    Selected_Port.readBytes(bufferackfinal, 1);
                    //System.out.println(" " + bufferackfinal[0]);
                    if (bufferackfinal[0] == 'B') {
                        String_size -= 30;
                        System.out.println("RECEBIDO");
                        sucesso_envio = true;
                    }
                }
            }
        }


    //Função para enviar imagens entre os DevKits
    public static void SendImage(SerialPort Selected_Port) throws IOException {
        //String OS_BEING_USED = OS_USED();
        int nPackets; //A quantidade de pacotes a enviar após a divisão da mensagem em tramas de 30 bits
        float BytesFromFile;
        boolean sucesso = false;
        int Image_size; //Cantidade de bytes contida no ficheiro de texto
        int text_newpos = 0; //A cada iteração a posição do array que contem o texto tem de ser incrementada
        int counter = 0;
        int insert_counter = 0; // counter para a inserção dos dados do ficheiro na payload a enviar
        Scanner input2 = new Scanner(System.in);
        boolean sucesso_envio = false;
        int size_contador = 0;
        System.out.println("Introduza o path exato do ficheiro de texto a enviar");
        String Path = input2.nextLine();
        //String Text_File2 = (Files.readString(Paths.get("/home/johnnyminho/IdeaProjects/Files_Java/Boas")));
        byte[] Image_File = (Files.readAllBytes(Paths.get(Path)));
        //OutputStream output = Selected_Port.getOutputStream();
        Image_size = Image_File.length;
        BytesFromFile = Image_File.length;
        nPackets = (int) Math.ceil(BytesFromFile / 30);
        System.out.println(" " + nPackets);
        for (counter = 0; counter < nPackets; counter++) {
            sucesso_envio = false;
            byte[] bytesToSend = new byte[30];
            if (Image_size > 30) {
                size_contador = 30;
            } else {
                size_contador = Image_size;
                bytesToSend = new byte[size_contador];
            }
            for (insert_counter = 0; insert_counter < size_contador; insert_counter++) {
                bytesToSend[insert_counter] = Image_File[insert_counter + text_newpos];
                System.out.println(" " + (char) bytesToSend[insert_counter]);
            }
            Selected_Port.writeBytes(bytesToSend, size_contador);
            while(Selected_Port.bytesAwaitingWrite() <=0 && counter == 1){
                if(counter == 1){
                    break; // este passo é necessário visto que o número de bytes à espera de serem escritos antes do 1 packet é sempre 0
                }
            }
          /*  try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            */
            text_newpos = text_newpos + 30; //proxima posição no ficheiro de texto será 30 bytes à frente da que foi enviad
            while (!sucesso_envio) {
                byte[] bufferackfinal = new byte[2];
                Selected_Port.readBytes(bufferackfinal, 1);
                System.out.println(" " + bufferackfinal[0]);
                if (bufferackfinal[0] == 'B') {
                    Image_size -= 30;
                    System.out.println("RECEBIDO");
                    sucesso_envio = true;
                }
            }
        }
    }

    public static void Receive_Text(SerialPort Selected_Port, String File_Store) throws IOException {
        boolean fim = false;
        InputStream arduino_input = Selected_Port.getInputStream();
        StringBuilder file_string = new StringBuilder();
        //Reader input = new InputStreamReader(arduino_input, StandardCharsets.UTF_8);
        //Scanner input = new Scanner(arduino_input).useDelimiter("\\A");
        File file_save = new File(File_Store);

        String conteudo;
        byte[] data = new byte[372];
        if(file_save.exists()){
            file_save.delete();
        }
        else{
            file_save.createNewFile();
        }
        try{
        while(arduino_input.available()>0){
            int NumBytes = arduino_input.read(data);
            if(NumBytes < 0 ){
                break;
            }
            file_string.append(new String(data, 0, NumBytes));
           if(file_string.toString().contains("*")){
                int i = file_string.indexOf("*");
                file_string.delete(file_string.lastIndexOf("*"), file_string.length());
                /*while(file_string.toString().contains("\0")){
                    i = file_string.indexOf("\0");
                        file_string.delete(i,i+1);
                    }*/
                }
            }
        } catch (IOException e4) {
            e4.printStackTrace();
        }
        PrintWriter out = new PrintWriter(file_save);
        System.out.println(file_string);
        out.write(String.valueOf(file_string));
        out.close();

        /*while(!(conteudo = new String(arduino_input.readAllBytes(), StandardCharsets.UTF_8)).contains("*")){
            System.out.println(Selected_Port.bytesAvailable());
        }
        System.out.println("DEBUG");
        System.out.println(Selected_Port.bytesAvailable());
        Selected_Port.readBytes(data, Selected_Port.bytesAvailable());
        String converted_data = new String(data, StandardCharsets.UTF_8);
        Selected_Port.readBytes(data, 372);
       // Files.write(Path.of(File_Store),data);
        while (!fim) {
                String data_converter = new String(data, StandardCharsets.UTF_8);
                char[] data_converted = new char[31];
                data_converted = data_converter.toCharArray();
                out.write(data_converted);
                out.close();
                if (data_converter.contains("*")) {
                    System.out.println("Entrei");
                    fim = true;
                }
            }*/
        }
    public static void Receive_Image(SerialPort Selected_Port, String File_Store) throws IOException {
        boolean fim = false;
        InputStream arduino_input = Selected_Port.getInputStream();
        StringBuilder file_string = new StringBuilder();
        //Reader input = new InputStreamReader(arduino_input, StandardCharsets.UTF_8);
        //Scanner input = new Scanner(arduino_input).useDelimiter("\\A");
        File file_save = new File(File_Store);

        String conteudo;
        byte[] data = new byte[5120];
        if(file_save.exists()){
            file_save.delete();
        }
        else{
            file_save.createNewFile();
        }
        try (FileOutputStream nova_imagem = new FileOutputStream(file_save, true)){
            while(arduino_input.available()>0){
                int NumBytes = arduino_input.read(data);
                if(NumBytes < 0 ){
                    break;
                }
                if(file_string.toString().contains("*")){
                    break;
                }
                else{
                    nova_imagem.write(data, 0, NumBytes);
                }

            }
        } catch (IOException e4) {
            e4.printStackTrace();
        }
        /*PrintWriter out = new PrintWriter(file_save);
        System.out.println(file_string);
        out.write(String.valueOf(file_string));
        out.close();*/
    }

    public static void chat(SerialPort Selected_Port) throws IOException {
        Scanner inputchat = new Scanner(System.in);
        Console input = System.console();
        String to_send = " ";
        boolean Leave_chat = false;
        boolean valid_op = false;
        int option_inp = 0;

        do{
            valid_op = false;
            System.out.println(" ____________________________________________________");
            System.out.println("|     1-> ENVIAR MENSAGEM                            |");
            System.out.println("|     2-> RECEBER MENSAGEM                           |");
            System.out.println("|     3-> SAIR  DO CHAT                              |");
            System.out.println(" ----------------------------------------------------");
            System.out.println("USER: " + Selected_Port);
            if (inputchat.hasNextInt()) {
                option_inp = inputchat.nextInt();
                valid_op = true;
            }
            while (option_inp < 1 || option_inp > 3 || !valid_op) {
                System.out.println("Opção Inválida");
                option_inp = inputchat.nextInt();
            }
            inputchat.nextLine();
            switch (option_inp) {
                case 1:
                    System.out.println("Digite a mensagem que quer enviar: ");
                    to_send = inputchat.nextLine();
                    byte[] byte_send = to_send.getBytes(StandardCharsets.UTF_8);
                    int nPackets; //A quantidade de pacotes a enviar após a divisão da mensagem em tramas de 30 bits
                    float BytesFromFile;
                    boolean sucesso = false;
                    int String_size; //Cantidade de bytes contida no ficheiro de texto
                    int text_newpos = 0; //A cada iteração a posição do array que contem o texto tem de ser incrementada
                    int counter = 0;
                    int insert_counter = 0; // counter para a inserção dos dados do ficheiro na payload a enviar
                    Scanner input2 = new Scanner(System.in);
                    boolean sucesso_envio = false;
                    int size_contador = 0;
                    //OutputStream output = Selected_Port.getOutputStream();
                    String_size = to_send.length();
                    BytesFromFile = byte_send.length;
                    nPackets = (int) Math.ceil(BytesFromFile / 30);
                    System.out.println(" " + nPackets);
                    for (counter = 0; counter < nPackets; counter++) {
                        sucesso_envio = false;
                        byte[] bytesToSend = new byte[30];
                        if (String_size >= 30) {
                            size_contador = 30;
                        } else {
                            size_contador = String_size;
                            bytesToSend = new byte[size_contador];
                        }
                        for (insert_counter = 0; insert_counter < size_contador; insert_counter++) {
                            bytesToSend[insert_counter] = byte_send[insert_counter + text_newpos];
                            System.out.print(" " + (char) bytesToSend[insert_counter]);
                        }
                        Selected_Port.writeBytes(bytesToSend, size_contador);
                        while(Selected_Port.bytesAwaitingWrite() <=0 && counter == 1){
                            if(counter == 1){
                                break; // este passo é necessário visto que o número de bytes à espera de serem escritos antes do 1 packet é sempre 0
                            }
                        }
                        text_newpos = text_newpos + 30; //proxima posição no ficheiro de texto será 30 bytes à frente da que foi enviad
                        while (!sucesso_envio) {
                            byte[] bufferackfinal = new byte[2];
                            Selected_Port.readBytes(bufferackfinal, 1);
                            //System.out.println(" " + bufferackfinal[0]);
                            if (bufferackfinal[0] == 'B') {
                                String_size -= 30;
                                sucesso_envio = true;
                            }
                        }
                    }

                    break;
                case 2:
                    boolean sucesso_receber = false;
                    int counter_receber = 30;
                    byte[] data = new byte[30];

                    InputStream arduino_input = Selected_Port.getInputStream();
                    StringBuilder file_string = new StringBuilder();

                    String conteudo;
                    try{
                        while(Selected_Port.bytesAvailable() <=0);
                        while(arduino_input.available()>0){
                            int NumBytes = arduino_input.read(data);
                            if(NumBytes < 0 ){
                                break;
                            }
                            file_string.append(new String(data, 0, NumBytes));
                            if(file_string.toString().contains("*") || file_string.toString().contains("\0") ){
                                int i = file_string.indexOf("*");
                                file_string.delete(i,i+1);
                                while(file_string.toString().contains("\0")){
                                    i = file_string.indexOf("\0");
                                    file_string.delete(i,i+1);
                                }
                            }
                        }
                    } catch (IOException e4) {
                        e4.printStackTrace();
                    }
                    System.out.println("Recebido :");
                    System.out.println(file_string);
                    break;
                case 3:
                    Leave_chat = true;
                    break;
            }
        } while (!Leave_chat);
    }
}